// Toggle	

jQuery(window).load(function(){
     
    $('.toggle-view li').click(function () {
 
        var text = $(this).children('div.toggle-content');
 
        if (text.is(':hidden')) {
            text.slideDown('200');
            $(this).children('span').html('<i class="icon-minus"></i>');    
        } else {
            text.slideUp('200');
            $(this).children('span').html('<i class="icon-plus"></i>');    
        }
         
    });
 
});

// Twitter

$(document).ready(function(){
    $('#tweetFeed').jTweetsAnywhere({
        username: '4grafx',
        count: 2,
        showTweetFeed: {
            showProfileImages: false,
            showUserScreenNames: false,
            showUserFullNames: true,
            showActionReply: false,
            showActionRetweet: false,
            showActionFavorite: false
        },
        showTweetBox: {
            label: '<span style="color: #303030">Spread the word ...</span>'
        }
    });
});

// Twitter Sidebar

$(document).ready(function(){
    $('#tweetFeed-sidebar').jTweetsAnywhere({
        username: '4grafx',
        count: 2,
        showTweetFeed: {
            showProfileImages: false,
            showUserScreenNames: false,
            showUserFullNames: true,
            showActionReply: true,
            showActionRetweet: true,
            showActionFavorite: true
        },
        showTweetBox: {
            label: '<span style="color: #303030">Spread the word ...</span>'
        }
    });
});

// Carousel

$(window).load(function(){


			//	Responsive layout, resizing the items
			$('#carousel-works').carouFredSel({
				responsive: true,
				width: '100%',
				auto: false,
				circular	: false,
				infinite	: false,
				prev : {
					button		: "#car_prev",
					key			: "left",
						},
				next : {
					button		: "#car_next",
					key			: "right",
							},
				swipe: {
					onMouse: true,
					onTouch: true
					},
				items: {
					visible: {
						min: 1,
						max: 3
					}
				}
			});
			
			//	Responsive layout, resizing the items
			$('.carousel-type2').carouFredSel({
				responsive: true,
				width: '100%',
				auto: false,
				circular	: false,
				infinite	: false,
				prev : {
					button		: "#car_prev2",
					key			: "left",
						},
				next : {
					button		: "#car_next2",
					key			: "right",
							},
				swipe: {
					onMouse: true,
					onTouch: true
					},
				items: {
					visible: {
						min: 1,
						max: 1
					}
				}
			});

		});

// Tooltips Tipsy 

jQuery(window).load(function() {
			$('.has-tipsy').tipsy({gravity: $.fn.tipsy.autoNS, fade:true});
});



// Accordion

$(document).ready(function() {
	var cur_stus;
	
	//close all on default
	$('.accordion .accordion-content').hide();
	$('.accordion .accordion-title').attr('stus', '');
	       
	//open default data
	$('.accordion .accordion-content:eq(0)').slideDown();
	$('.accordion .accordion-title:eq(0)').attr('stus', 'active').addClass('active');

	$('.accordion .accordion-title').click(function(){
		cur_stus = $(this).attr('stus');
		if(cur_stus != "active")
		{
			//reset everthing - content and attribute
			$('.accordion .accordion-content').slideUp();
			$('.accordion .accordion-title').attr('stus', '').removeClass('active');
			
			//then open the clicked data
			$(this).next().slideDown();
			$(this).attr('stus', 'active').addClass('active');
		}
		//Remove else part if do not want to close the current opened data
		else
		{
			$(this).next().slideUp();
			$(this).attr('stus', '').removeClass('active');
		}
		return false;
	});
});


// Titan Light Box 

jQuery(document).ready(function($) {
		$('.titan-lb').lightbox({
			'scrolling': 'auto',
			theme: 'default'
		});
		 prettyPrint();
	});

// BACK TO TOP
  
$(document).ready(function(){
 
        $(window).scroll(function(){
            if ($(this).scrollTop() > 100) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
        });
 
        $('.scrollup').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
 
});


// Overlay



    $(document).ready(function(){
    $(".image-overlay").hover(function(){
        $(this).find(".overlay-icon").slideDown("slow");
    },function(){
        $(this).find(".overlay-icon").slideUp("slow");    
    });
    });
	
