// Jquery coookie plugin
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};

jQuery(document).ready(function(){
	/* cookie vars */
	jQuery('#options-handler').toggle(function() {
		jQuery(this).animate({"marginLeft": "-=216px"}, "slow").addClass('active');
		jQuery('#switch-panel').animate({"marginLeft": "-=216px"}, "slow"); 
	}, 

	function() {
		jQuery('#switch-panel').animate({"marginLeft": "+=216px"}, "slow");
		jQuery(this).animate({"marginLeft": "+=216px"}, "slow").removeClass('active'); 
	});

	/* cookie vars */
	
	var cookie_options = { path: 'default.htm', expires: 7 };
	
	var get_cookie = jQuery.cookie('Rivers_skin');
	
	if (get_cookie == null)
	{
		get_cookie = '#EA005A';
	}
	
	
	var get_bg = jQuery.cookie('Rivers_background');
	if (get_bg == null)
	{
		get_bg = 'images/backgrounds/bg9.png';
	}
	
	var get_layout = jQuery.cookie('Rivers_layout');
	
	if (get_layout == null)
	{
		get_layout = 'full';
	}
	
		
	jQuery('body').css('background-image', 'url(' + get_bg + ')');
	jQuery('.main-wrapper').addClass(get_layout);
	
	jQuery('#theme_layout_bg a').live('click', function() {
		jQuery('#theme_layout_bg a').removeClass('active');
		jQuery(this).addClass('active');
		bg = jQuery(this).attr('rel');
		var fullBg = 'images/backgrounds/' + bg + '.png';
		jQuery('body').css('background-image', 'url(' + fullBg + ')');
		
		jQuery.cookie('Rivers_background', fullBg, cookie_options);
		
		return false; 
	});
	
		
});
